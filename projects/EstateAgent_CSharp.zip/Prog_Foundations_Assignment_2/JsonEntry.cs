﻿namespace Prog_Foundations_Assignment_2
{
    /// 
    /// DO NOT EDIT THIS CLASS
    /// 
    internal class JsonEntry
    {
        public double Price { get; set; }
        public string Postcode { get; set; }
        public uint NumBathrooms { get; set; }
        public uint NumBedrooms { get; set; }
        public bool HasGarden { get; set; }
        public DateTime DatePosted { get; set; }
    }
}
