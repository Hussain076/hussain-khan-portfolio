﻿namespace Prog_Foundations_Assignment_2
{
    internal class House
    {
        // Add your class code into this area
    }
}
