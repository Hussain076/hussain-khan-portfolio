﻿namespace Prog_Foundations_Assignment_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please remove this for submission. Read Assignment Brief and instructions for building this app.");

            // Create basic estate agent
            EstateAgent estateAgent = new EstateAgent();

            // Try and print the loaded house data
            estateAgent.PrintAllHouseData();
        }
    }
}


