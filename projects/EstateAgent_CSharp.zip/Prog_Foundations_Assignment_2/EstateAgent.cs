﻿using System.Text.Json;

namespace Prog_Foundations_Assignment_2
{
    internal class EstateAgent
    {
        private List<House> HousesToSell;

        public EstateAgent()
        {
            ///
            /// DO NOT EDIT
            ///

            // Create list and load houses from file
            HousesToSell = new List<House>();
            LoadHousesFromFile("HouseJson.json");
        }

        
        private void LoadHousesFromFile(string filename)
        {
            ///
            /// DO NOT EDIT
            /// 

            // Read Json from file as a single string
            string jsonFile = File.ReadAllText(filename);
            // Deserialise the data into a List of JsonEntry objects
            List<JsonEntry>? housesFromFile = JsonSerializer.Deserialize<List<JsonEntry>>(jsonFile);
            // Make sure the list is valid
            if (housesFromFile != null)
            {
                // Go over each entry
                foreach (JsonEntry entry in housesFromFile)
                {
                    // Create new house
                    House new_house = CreateNewHouse(entry);

                    // Check house data is valid before adding to the list
                    if (IsHouseValid(new_house))
                    {
                        HousesToSell.Add(new_house);
                    }
                }
            }
        }

        private House CreateNewHouse(JsonEntry creation_data)
        {
            // Fill out the function so each house to created using the JsonEntry data
                // Function must return a new instance of House
            House house = new House();
            
            return house;
        }

        private bool IsHouseValid(House house)
        {
            // Function must check if house is valid
            //      no negative prices
            //      must have at least one bedroom and bathroom
            //      must be posted before todays date.
            // Return true of house if valid, else returns false
            return false;
        }

        public void SortHousesPrice(bool low_to_high)
        {
            ///
            /// DO NOT EDIT
            /// 
            if(low_to_high)
            {
                SortLowToHighPrice();
            }
            else
            {
                SortHighToLowPrice();
            }
        }

        private void SortHighToLowPrice()
        {
            // Function must sort the houses in the HousesToSell list from Lowest to Highest Price
            // You will need to create a function that you can use to customise the sorter
        }

        private void SortLowToHighPrice()
        {
            // Function must sort the houses in the HousesToSell list from Highest to Lowest Price
            // Similar to above, you will need to create a function that you can use to customise the sorter
        }

        public List<House>? GetHousesInPostcode(string postcode)
        {
            List<House> HousesWithPostcode = new List<House>();
            // Function must return all the houses that have a matching postcode to the argument.
            // Add all houses that match to the HousesWithPostcode List
            return HousesWithPostcode;
        }

        public void PrintAllHouseData()
        {
            // Function must loop through the houses you can sell and list print their details
        }

        public double AverageHousePrice()
        {
            // Function must calculate the average price of the houses that are up for sale
            return -1.0;
        }

        public int NumberOfHouses()
        {
            // Function should calculate the number of houses that are for sale
            return -1;
        }
    }
}
